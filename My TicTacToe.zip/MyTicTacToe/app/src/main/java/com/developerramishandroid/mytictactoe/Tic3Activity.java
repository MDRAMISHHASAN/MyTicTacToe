package com.developerramishandroid.mytictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewTreeObserver;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Tic3Activity extends AppCompatActivity {

    private View background;
    MediaPlayer player;
    private InterstitialAd mInterstitialAd;
    FloatingActionButton fabMain,fabOne,fabTwo,fabThree,fabFour,fabFive;
    Boolean isMenuOpen = false;
    OvershootInterpolator interpolator = new OvershootInterpolator();

    // for playing the music
    public void fabOneClick(View view)
    {
        player = MediaPlayer.create(this, R.raw.guitar);
        player.start();
        Toast.makeText(this, "Guitar", Toast.LENGTH_SHORT).show();
    }
    // for playing the music

    public void fabFourClick(View view)
    {
        player = MediaPlayer.create(this, R.raw.drum_machine);
        player.start();
        Toast.makeText(this, "Drum Machine", Toast.LENGTH_SHORT).show();
    }
    // for playing the music

    public void fabFiveClick(View view)
    {
        player = MediaPlayer.create(this, R.raw.drum_pad);
        player.start();
        Toast.makeText(this, "Drum Pad", Toast.LENGTH_SHORT).show();
    }
    // for pausing the music
    public void fabTwoClick(View view)
    {
        player.pause();
        Toast.makeText(this, "Music paused.", Toast.LENGTH_SHORT).show();
    }
    /*
    public void stop(View view){
        player.stop();
    }

     */
    TextView status;
    String user1,user2;
    boolean gameActive = true;
    // Player representation
    // 0 - X
    // 1 - O
    int activePlayer = 0;
    int[] gameState = {2, 2 , 2, 2, 2, 2, 2, 2, 2};
    //    State meanings:
    //    0 - X
    //    1 - O
    //    2 - Null
    int[][] winPositions = {{0,1,2}, {3,4,5}, {6,7,8},
            {0,3,6}, {1,4,7}, {2,5,8},
            {0,4,8}, {2,4,6}};



        public void playerTap (View view){
        ImageView img = (ImageView) view;
        // ImageView[] imgv;
        int tappedImage = Integer.parseInt(img.getTag().toString());
/*
        if(!gameActive){

            Toast.makeText(this, "Restart Game", Toast.LENGTH_SHORT).show();
            //gameRestart(view);
        }

 */
     

        if (gameState[tappedImage] == 2) {
            gameState[tappedImage] = activePlayer;
            img.setTranslationY(-300f);
            if (activePlayer == 0) {
                //       imgv =img;
                img.setImageResource(R.drawable.x);
                activePlayer = 1;
                status = findViewById(R.id.status);
                status.setText("O's Turn");
            } else {
                img.setImageResource(R.drawable.o);
                activePlayer = 0;
                status = findViewById(R.id.status);
                String user2 = "X's Turn";
                status.setText(user2);
            }
            img.animate().translationYBy(300f).setDuration(300);
        }
        // Check if any player has won
        for (int[] winPosition : winPositions) {
            if (gameState[winPosition[0]] == gameState[winPosition[1]] &&
                    gameState[winPosition[1]] == gameState[winPosition[2]] &&
                    gameState[winPosition[0]] != 2) {
                // Somebody has won! - Find out who!
                //img.setImageResource(R.drawable.x);

                String winnerStr;
                gameActive = false;
                if (!gameActive) {
                    againSetGameNotActive();
                }

                if (gameState[winPosition[0]] == 0 ) {
                    winnerStr = "X has won";
                    // gameRestart(view);


                    img.setImageResource(R.drawable.green_x);
                } else
                {
                    winnerStr = "O has won";
                    //   gameRestart(view);
                    img.setImageResource(R.drawable.green_o);
                }

                // Update the status bar for winner announcement
                TextView status = findViewById(R.id.status);

                status.setText(winnerStr);

                showAd();

            } else if (gameState[0] != 2 && gameState[1] != 2 && gameState[2] != 2 && gameState[3] != 2 && gameState[4] != 2 && gameState[5] != 2 && gameState[6] != 2 && gameState[7] != 2
                    && gameState[8] != 2) {
                gameActive = false;
                if (!gameActive) {
                    againSetGameNotActive();
                }

            }


        }

    }

    private void againSetGameNotActive()
    {
        gameActive=false;

    }

    public void gameRestart(View view) {

        Toast.makeText(this, "Restart game \n(Anyone has won or game has been tie)", Toast.LENGTH_SHORT).show();


        if(!gameActive) {
            gameActive = true;
            activePlayer = 0;
            for (int i = 0; i < gameState.length; i++) {
                gameState[i] = 2;
            }
            ((ImageView) findViewById(R.id.imageView0)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView1)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView2)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView3)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView4)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView5)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView6)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView7)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView8)).setImageResource(0);


            TextView status = findViewById(R.id.status);
            status.setText("X's Turn");

        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.do_not_move,R.anim.do_not_move);
        setContentView(R.layout.activity_tic3);

        background = findViewById(R.id.background);

        if (savedInstanceState == null) {
            background.setVisibility(View.INVISIBLE);

            final ViewTreeObserver viewTreeObserver = background.getViewTreeObserver();

            if (viewTreeObserver.isAlive()) {
                viewTreeObserver.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

                    @Override
                    public void onGlobalLayout() {
                        circularRevealActivity();
                        background.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }

                });
            }

        }



        initFabMenu();

        prepareAd();
    }


    private void circularRevealActivity() {
        int cx = background.getRight() - getDips(100) ;
        int cy = background.getBottom() - getDips(500) ;

        float finalRadius = Math.max(background.getWidth(), background.getHeight());

        Animator circularReveal = ViewAnimationUtils.createCircularReveal(
                background,
                cx,
                cy,
                0,
                finalRadius);

        circularReveal.setDuration(2000);
        background.setVisibility(View.VISIBLE);
        circularReveal.start();

    }

    private int getDips(int dps) {
        Resources resources = getResources();
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dps,
                resources.getDisplayMetrics());
    }

    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            int cx = background.getWidth() - getDips(100);
            int cy = background.getBottom() - getDips(500);

            float finalRadius = Math.max(background.getWidth(), background.getHeight());
            Animator circularReveal = ViewAnimationUtils.createCircularReveal(background, cx, cy, finalRadius, 0);

            circularReveal.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animator) {

                }

                @Override
                public void onAnimationEnd(Animator animator) {
                    background.setVisibility(View.INVISIBLE);
                    finish();
                }

                @Override
                public void onAnimationCancel(Animator animator) {

                }

                @Override
                public void onAnimationRepeat(Animator animator) {

                }
            });
            circularReveal.setDuration(2000);
            circularReveal.start();
        }
        else {
            super.onBackPressed();
        }
    }

    private void initFabMenu()
    {
        fabMain = findViewById(R.id.fabMain);
        fabOne = findViewById(R.id.fabOne);
        fabTwo = findViewById(R.id.fabTwo);
        fabThree = findViewById(R.id.fabThree);
        fabFour = findViewById(R.id.fabFour);
        fabFive = findViewById(R.id.fabFive);


        fabOne.setAlpha(0f);
        fabTwo.setAlpha(0f);
        fabThree.setAlpha(0f);
        fabFour.setAlpha(0f);
        fabFive.setAlpha(0f);

        fabOne.setTranslationY(200f);
        fabTwo.setTranslationY(200f);
        fabThree.setTranslationY(200f);
        fabFour.setTranslationY(200f);
        fabFive.setTranslationY(200f);

        // fabOne.setTranslationY(100f);

    }

    public void openMenu()
    {
        isMenuOpen = !isMenuOpen;

        fabMain.animate().setInterpolator(interpolator).rotation(45f).setDuration(700).start();
        fabOne.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(700).start();
        fabTwo.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(700).start();
        fabThree.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(700).start();
        fabFour.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(700).start();
        fabFive.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(700).start();


    }

    public void closeMenu()
    {
        isMenuOpen = !isMenuOpen;

        fabMain.animate().setInterpolator(interpolator).rotation(0f).setDuration(700).start();
        fabOne.animate().translationY(200f).alpha(0f).setInterpolator(interpolator).setDuration(700).start();
        fabTwo.animate().translationY(200f).alpha(0f).setInterpolator(interpolator).setDuration(700).start();
        fabThree.animate().translationY(200f).alpha(0f).setInterpolator(interpolator).setDuration(700).start();
        fabFour.animate().translationY(200f).alpha(0f).setInterpolator(interpolator).setDuration(700).start();
        fabFive.animate().translationY(200f).alpha(0f).setInterpolator(interpolator).setDuration(700).start();



    }


    public void fabMainClick(View view)
    {
        if (!isMenuOpen)
            openMenu();
        else
            closeMenu();
    }




    public void prepareAd()
    {
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-5151712602206297/3311637703");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void showAd()
    {
        ScheduledExecutorService scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutorService.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (mInterstitialAd.isLoaded())
                        {
                            mInterstitialAd.show();
                        }
                        else
                        {
                            Log.i("ad", "Interstitial ad is not loaded");
                        }
                        prepareAd();
                    }
                });
            }
        },2,20, TimeUnit.SECONDS);
    }
}
