package com.developerramishandroid.mytictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewTreeObserver;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Tic5Activity extends AppCompatActivity {

    private View background;
    FloatingActionButton fabMain,fabOne,fabTwo,fabThree;
    Boolean isMenuOpen = false;
    OvershootInterpolator interpolator = new OvershootInterpolator();
    MediaPlayer player;

    // for playing the music
    public void fabOneClick(View view)
    {
        player.start();
        Toast.makeText(this, "This button is used for playing background music.", Toast.LENGTH_SHORT).show();
    }
    // for pausing the music
    public void fabTwoClick(View view)
    {
        player.pause();
        Toast.makeText(this, "This button is used for pausing background music.", Toast.LENGTH_SHORT).show();
    }


    boolean gameActive = true;
    // Player representation
    // 0 - X
    // 1 - O
    long activePlayer = 0;
    long[] gameState = {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2};
    //    State meanings:
    //    0 - X
    //    1 - O
    //    2 - Null
    long[][] winPositions = {{0,1,2,3,4}, {5,6,7,8,9}, {10,11,12,13,14},{15,16,17,18,19},{20,21,22,23,24},
                           {0,5,10,15,20}, {1,6,11,16}, {2,7,12,17,22},{3,8,13,18,23},{4,9,14,19,24},
                           {0,6,12,18,24}, {4,8,12,16,20}};

    public void playerTap(View view){
        ImageView img = (ImageView) view;
        long tappedImage = Integer.parseInt(img.getTag().toString());
       /*
        if(!gameActive){
            gameReset(view);
        }

        */
        if(gameState[(int) tappedImage] == 2) {
            gameState[(int) tappedImage] = activePlayer;
            img.setTranslationY(-1000f);
            if (activePlayer == 0) {
                img.setImageResource(R.drawable.x);
                activePlayer = 1;
                TextView status = findViewById(R.id.status);
                status.setText("O's Turn - Tap to play");
            } else {
                img.setImageResource(R.drawable.o);
                activePlayer = 0;
                TextView status = findViewById(R.id.status);
                status.setText("X's Turn - Tap to play");
            }
            img.animate().translationYBy(1000f).setDuration(300);
        }
        // Check if any player has won
        for(long[] winPosition: winPositions){
            if(gameState[(int) winPosition[0]] == gameState[(int) winPosition[1]] && gameState[(int) winPosition[1]] == gameState[(int) winPosition[2]] &&
                    gameState[(int) winPosition[2]] == gameState[(int) winPosition[3]] && gameState[(int) winPosition[3]] == gameState[(int) winPosition[4]] && gameState[(int) winPosition[0]]!=2){
                // Somebody has won! - Find out who!
                String winnerStr;
                gameActive = false;
                if(!gameActive)
                {
                    againSetGameNotActive();
                }

                if(gameState[(int) winPosition[0]] == 0){
                    winnerStr = "X has won";
                    // gameRestart(view);
                }
                else{
                    winnerStr = "O has won";
                    //   gameRestart(view);
                }
                // Update the status bar for winner announcement
                TextView status = findViewById(R.id.status);
                status.setText(winnerStr);

            }
            else if(gameState[0] !=2 && gameState[1]!=2 && gameState[2]!=2 && gameState[3]!=2 && gameState[4] !=2 && gameState[5]!=2 && gameState[6]!=2 && gameState[7]!=2
                    && gameState[8] !=2 && gameState[9]!=2 && gameState[10]!=2 && gameState[11]!=2 && gameState[12] !=2 && gameState[13]!=2 && gameState[14]!=2
                    && gameState[15]!=2 && gameState[16]!=2 && gameState[17]!=2 && gameState[18]!=2 && gameState[19]!=2 && gameState[20]!=2 && gameState[21]!=2
                    && gameState[22]!=2 && gameState[23]!=2 && gameState[24]!=2)
            {
                gameActive = false;
                if(!gameActive)
                {
                    againSetGameNotActive();
                }

            }



        }

    }

    private void againSetGameNotActive()
    {
        gameActive=false;

    }

    public void gameRestart(View view) {

        Toast.makeText(this, "This button is used for Restarting game when anyone has won or the game has been tie.", Toast.LENGTH_SHORT).show();


        if(!gameActive) {
            gameActive = true;
            activePlayer = 0;
            for (long i = 0; i < gameState.length; i++) {
                gameState[(int) i] = 2;
            }
            ((ImageView) findViewById(R.id.imageView0)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView1)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView2)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView3)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView4)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView5)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView6)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView7)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView8)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView9)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView10)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView11)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView12)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView13)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView14)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView15)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView16)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView17)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView18)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView19)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView20)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView21)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView22)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView23)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView24)).setImageResource(0);


            TextView status = findViewById(R.id.status);
            status.setText("X's Turn - Tap to play");

        }
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.do_not_move,R.anim.do_not_move);
        setContentView(R.layout.activity_tic5);

        player = MediaPlayer.create(this, R.raw.music);

        background = findViewById(R.id.background);

        if (savedInstanceState == null) {
            background.setVisibility(View.INVISIBLE);

            final ViewTreeObserver viewTreeObserver = background.getViewTreeObserver();

            if (viewTreeObserver.isAlive()) {
                viewTreeObserver.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

                    @Override
                    public void onGlobalLayout() {
                        circularRevealActivity();
                        background.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }

                });
            }

        }


        initFabMenu();
    }


    private void circularRevealActivity() {
        int cx = background.getRight() - getDips(100) ;
        int cy = background.getBottom() - getDips(300) ;

        float finalRadius = Math.max(background.getWidth(), background.getHeight());

        Animator circularReveal = ViewAnimationUtils.createCircularReveal(
                background,
                cx,
                cy,
                0,
                finalRadius);

        circularReveal.setDuration(2000);
        background.setVisibility(View.VISIBLE);
        circularReveal.start();

    }

    private int getDips(int dps) {
        Resources resources = getResources();
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dps,
                resources.getDisplayMetrics());
    }

    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            int cx = background.getWidth() - getDips(100);
            int cy = background.getBottom() - getDips(300);

            float finalRadius = Math.max(background.getWidth(), background.getHeight());
            Animator circularReveal = ViewAnimationUtils.createCircularReveal(background, cx, cy, finalRadius, 0);

            circularReveal.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animator) {

                }

                @Override
                public void onAnimationEnd(Animator animator) {
                    background.setVisibility(View.INVISIBLE);
                    finish();
                }

                @Override
                public void onAnimationCancel(Animator animator) {

                }

                @Override
                public void onAnimationRepeat(Animator animator) {

                }
            });
            circularReveal.setDuration(2000);
            circularReveal.start();
        }
        else {
            super.onBackPressed();
        }
    }

    private void initFabMenu()
    {
        fabMain = findViewById(R.id.fabMain);
        fabOne = findViewById(R.id.fabOne);
        fabTwo = findViewById(R.id.fabTwo);
        fabThree = findViewById(R.id.fabThree);

        fabOne.setAlpha(0f);
        fabTwo.setAlpha(0f);
        fabThree.setAlpha(0f);

        fabOne.setTranslationY(1000f);
        fabTwo.setTranslationY(1000f);
        fabThree.setTranslationY(1000f);

        // fabOne.setTranslationY(100f);

    }

    public void openMenu()
    {
        isMenuOpen = !isMenuOpen;

        fabMain.animate().setInterpolator(interpolator).rotation(45f).setDuration(300).start();
        fabOne.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(1000).start();
        fabTwo.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(1000).start();
        fabThree.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(1000).start();


    }

    public void closeMenu()
    {
        isMenuOpen = !isMenuOpen;

        fabMain.animate().setInterpolator(interpolator).rotation(0f).setDuration(300).start();
        fabOne.animate().translationY(1000f).alpha(0f).setInterpolator(interpolator).setDuration(300).start();
        fabTwo.animate().translationY(1000f).alpha(0f).setInterpolator(interpolator).setDuration(300).start();
        fabThree.animate().translationY(1000f).alpha(0f).setInterpolator(interpolator).setDuration(300).start();



    }


    public void fabMainClick(View view)
    {
        if (!isMenuOpen)
            openMenu();
        else
            closeMenu();
    }



}
