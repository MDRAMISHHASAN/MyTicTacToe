package com.developerramishandroid.mytictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewTreeObserver;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Tic4Activity extends AppCompatActivity {

    private View background;
    FloatingActionButton fabMain,fabOne,fabTwo,fabThree,fabFour,fabFive;
    Boolean isMenuOpen = false;
    OvershootInterpolator interpolator = new OvershootInterpolator();
    MediaPlayer player;

    // for playing the music
    public void fabOneClick(View view)
    {
        player = MediaPlayer.create(this, R.raw.guitar);
        player.start();
        Toast.makeText(this, "Guitar", Toast.LENGTH_SHORT).show();
    }

    // for playing the music
    public void fabFourClick(View view)
    {
        player = MediaPlayer.create(this, R.raw.drum_machine);
        player.start();
        Toast.makeText(this, "Drum Machine", Toast.LENGTH_SHORT).show();
    }

    // for playing the music
    public void fabFiveClick(View view)
    {
        player = MediaPlayer.create(this, R.raw.drum_pad);
        player.start();
        Toast.makeText(this, "Drum Pad", Toast.LENGTH_SHORT).show();
    }
    // for pausing the music
    public void fabTwoClick(View view)
    {
        player.pause();
        Toast.makeText(this, "Music Paused", Toast.LENGTH_SHORT).show();
    }


    boolean gameActive = true;
    // Player representation
    // 0 - X
    // 1 - O
    int activePlayer = 0;
    int[] gameState = {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2};
    //    State meanings:
    //    0 - X
    //    1 - O
    //    2 - Null
    int[][] winPositions = {{0,1,2,3}, {4,5,6,7}, {8,9,10,11},{12,13,14,15},
                            {0,4,8,12}, {1,5,9,13}, {2,6,10,14},{3,7,11,15},
                            {0,5,10,15}, {3,6,9,12}};

    public void playerTap(View view){
        ImageView img = (ImageView) view;
        int tappedImage = Integer.parseInt(img.getTag().toString());
       /*
        if(!gameActive){
            gameReset(view);
        }

        */
        if(gameState[tappedImage] == 2) {
            gameState[tappedImage] = activePlayer;
            img.setTranslationY(-1000f);
            if (activePlayer == 0) {
                img.setImageResource(R.drawable.x);
                activePlayer = 1;
                TextView status = findViewById(R.id.status);
                status.setText("O's Turn - Tap to play");
            } else {
                img.setImageResource(R.drawable.o);
                activePlayer = 0;
                TextView status = findViewById(R.id.status);
                status.setText("X's Turn - Tap to play");
            }
            img.animate().translationYBy(1000f).setDuration(300);
        }
        // Check if any player has won
        for(int[] winPosition: winPositions){
            if(gameState[winPosition[0]] == gameState[winPosition[1]] && gameState[winPosition[1]] == gameState[winPosition[2]] &&
                    gameState[winPosition[2]] == gameState[winPosition[3]] && gameState[winPosition[0]]!=2){
                // Somebody has won! - Find out who!
                String winnerStr;
                gameActive = false;
                if(!gameActive)
                {
                    againSetGameNotActive();
                }

                if(gameState[winPosition[0]] == 0){
                    winnerStr = "X has won";
                    // gameRestart(view);
                }
                else{
                    winnerStr = "O has won";
                    //   gameRestart(view);
                }
                // Update the status bar for winner announcement
                TextView status = findViewById(R.id.status);
                status.setText(winnerStr);

            }
            else if(gameState[0] !=2 && gameState[1]!=2 && gameState[2]!=2 && gameState[3]!=2 && gameState[4] !=2 && gameState[5]!=2 && gameState[6]!=2 && gameState[7]!=2
                 && gameState[8] !=2 && gameState[9]!=2 && gameState[10]!=2 && gameState[11]!=2 && gameState[12] !=2 && gameState[13]!=2 && gameState[14]!=2 && gameState[15]!=2)
            {
                gameActive = false;
                if(!gameActive)
                {
                    againSetGameNotActive();
                }

            }



        }

    }

    private void againSetGameNotActive()
    {
        gameActive=false;

    }

    public void gameRestart(View view) {

        Toast.makeText(this, "Restart game \n(Anyone has won or game has been tie)", Toast.LENGTH_SHORT).show();


        if(!gameActive) {
            gameActive = true;
            activePlayer = 0;
            for (int i = 0; i < gameState.length; i++) {
                gameState[i] = 2;
            }
            ((ImageView) findViewById(R.id.imageView0)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView1)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView2)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView3)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView4)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView5)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView6)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView7)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView8)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView9)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView10)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView11)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView12)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView13)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView14)).setImageResource(0);
            ((ImageView) findViewById(R.id.imageView15)).setImageResource(0);


            TextView status = findViewById(R.id.status);
            status.setText("X's Turn - Tap to play");

        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.do_not_move,R.anim.do_not_move);
        setContentView(R.layout.activity_tic4);

        background = findViewById(R.id.background);

        if (savedInstanceState == null) {
            background.setVisibility(View.INVISIBLE);

            final ViewTreeObserver viewTreeObserver = background.getViewTreeObserver();

            if (viewTreeObserver.isAlive()) {
                viewTreeObserver.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

                    @Override
                    public void onGlobalLayout() {
                        circularRevealActivity();
                        background.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }

                });
            }

        }




        initFabMenu();
    }



    private void circularRevealActivity() {
        int cx = background.getRight() - getDips(300) ;
        int cy = background.getBottom() - getDips(300) ;

        float finalRadius = Math.max(background.getWidth(), background.getHeight());

        Animator circularReveal = ViewAnimationUtils.createCircularReveal(
                background,
                cx,
                cy,
                0,
                finalRadius);

        circularReveal.setDuration(2000);
        background.setVisibility(View.VISIBLE);
        circularReveal.start();

    }

    private int getDips(int dps) {
        Resources resources = getResources();
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dps,
                resources.getDisplayMetrics());
    }

    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            int cx = background.getWidth() - getDips(300);
            int cy = background.getBottom() - getDips(300);

            float finalRadius = Math.max(background.getWidth(), background.getHeight());
            Animator circularReveal = ViewAnimationUtils.createCircularReveal(background, cx, cy, finalRadius, 0);

            circularReveal.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animator) {

                }

                @Override
                public void onAnimationEnd(Animator animator) {
                    background.setVisibility(View.INVISIBLE);
                    finish();
                }

                @Override
                public void onAnimationCancel(Animator animator) {

                }

                @Override
                public void onAnimationRepeat(Animator animator) {

                }
            });
            circularReveal.setDuration(2000);
            circularReveal.start();
        }
        else {
            super.onBackPressed();
        }
    }


    private void initFabMenu()
    {
        fabMain = findViewById(R.id.fabMain);
        fabOne = findViewById(R.id.fabOne);
        fabTwo = findViewById(R.id.fabTwo);
        fabThree = findViewById(R.id.fabThree);
        fabFour = findViewById(R.id.fabFour);
        fabFive = findViewById(R.id.fabFive);

        fabOne.setAlpha(0f);
        fabTwo.setAlpha(0f);
        fabThree.setAlpha(0f);
        fabFour.setAlpha(0f);
        fabFive.setAlpha(0f);

        fabOne.setTranslationY(200f);
        fabTwo.setTranslationY(200f);
        fabThree.setTranslationY(200f);
        fabFour.setTranslationY(200f);
        fabFive.setTranslationY(200f);

        // fabOne.setTranslationY(100f);

    }

    public void openMenu()
    {
        isMenuOpen = !isMenuOpen;

        fabMain.animate().setInterpolator(interpolator).rotation(45f).setDuration(300).start();
        fabOne.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(300).start();
        fabTwo.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(300).start();
        fabThree.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(300).start();
        fabFour.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(700).start();
        fabFive.animate().translationY(0f).alpha(1f).setInterpolator(interpolator).setDuration(700).start();


    }

    public void closeMenu()
    {
        isMenuOpen = !isMenuOpen;

        fabMain.animate().setInterpolator(interpolator).rotation(0f).setDuration(300).start();
        fabOne.animate().translationY(200f).alpha(0f).setInterpolator(interpolator).setDuration(300).start();
        fabTwo.animate().translationY(200f).alpha(0f).setInterpolator(interpolator).setDuration(300).start();
        fabThree.animate().translationY(200f).alpha(0f).setInterpolator(interpolator).setDuration(300).start();
        fabFour.animate().translationY(200f).alpha(0f).setInterpolator(interpolator).setDuration(700).start();
        fabFive.animate().translationY(200f).alpha(0f).setInterpolator(interpolator).setDuration(700).start();



    }


    public void fabMainClick(View view)
    {
        if (!isMenuOpen)
        openMenu();
        else
            closeMenu();
    }




}
